import { HttpParams } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrl: './hosegriado.component.css'
})
export class HosegriadoComponent {

  elsoNapErtek!: number;
  masodikNapErtek!: number;
  harmadikNapErtek!: number;
  aktRiadoSzint!: string;
  aktRiadoSzinSzam!: number;
  eredmenyek: string[] = [];
  btnClass: string = "disabled";

  eredmenySzamitasa(): void {
    if (this.elsoNapErtek == null || this.masodikNapErtek == null || this.harmadikNapErtek == null) {
      this.btnClass = "disabled";
    } else {
      this.aktualisRiadoSzint();
      this.btnClass = "";
    }
  };

  aktualisRiadoSzint(): void {
    if (this.elsoNapErtek > 27 && this.masodikNapErtek > 27 && this.harmadikNapErtek > 27) {
      this.aktRiadoSzint = "Az aktuális hőségriadó szintje: 3. szintű";
      this.aktRiadoSzinSzam = 3;
    }
    else if (this.elsoNapErtek > 25 && this.masodikNapErtek > 25 && this.harmadikNapErtek > 25) {
      this.aktRiadoSzint = "Az aktuális hőségriadó szintje: 2. szintű";
      this.aktRiadoSzinSzam = 2;
    } else if (this.elsoNapErtek > 25 || this.masodikNapErtek > 25 || this.harmadikNapErtek > 25) {
      this.aktRiadoSzint = "Az aktuális hőségriadó szintje: 1. szintű";
      this.aktRiadoSzinSzam = 1;
    } else {
      this.aktRiadoSzint = "Az aktuális hőségriadó szintje: nincs riadó";
      this.aktRiadoSzinSzam = 0;
    }


  }

  mentes(): void {
    if (this.aktRiadoSzinSzam == 0) {
      this.eredmenyek.push(this.elsoNapErtek + ", " + this.masodikNapErtek + " és " + this.harmadikNapErtek + " esetén nem volt hőségriadó elrendelve")
    } else {
      this.eredmenyek.push(this.elsoNapErtek + ", " + this.masodikNapErtek + " és " + this.harmadikNapErtek + " esetén " + this.aktRiadoSzinSzam + ". szintű hőségriadó volt elrendelve")
    }

  }


}
