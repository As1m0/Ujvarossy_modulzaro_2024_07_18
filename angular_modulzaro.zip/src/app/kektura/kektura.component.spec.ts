import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KekturaComponent } from './kektura.component';

describe('KekturaComponent', () => {
  let component: KekturaComponent;
  let fixture: ComponentFixture<KekturaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [KekturaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KekturaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
